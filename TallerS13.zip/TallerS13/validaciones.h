int ingresarEnteroPositivo(char *mensaje);
float ingresarFlotante(char *mensaje);
void ingresarCadena(char *mensaje, char *cadena, int limite);

