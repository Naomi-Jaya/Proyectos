#include <stdio.h>

#define MAX_VEHICULOS 50

struct Vehiculo {
    int id;
    char tipo[20];
    char marca[30];
    char modelo[30];
    int anio;
    float precio;
    char estado[15];
};

void mostrarMenu();
void registrarVehiculo(struct Vehiculo inventario[], int *numVehiculos);
void mostrarInventario(struct Vehiculo inventario[], int numVehiculos);
void buscarVehiculos(struct Vehiculo inventario[], int numVehiculos);
void registrarVenta(struct Vehiculo inventario[], int numVehiculos);
void reporteVehiculosVendidos(struct Vehiculo inventario[], int numVehiculos);

void cargarInventario(struct Vehiculo inventario[], int *numVehiculos);
void guardarInventario(struct Vehiculo inventario[], int numVehiculos);
