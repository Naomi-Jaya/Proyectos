#include <stdio.h>
#include "vehiculos.h"
#include "validaciones.h"

int main() {
    struct Vehiculo inventario[MAX_VEHICULOS];
    int numVehiculos = 0;
    int opcion;

    inicializarVehiculos(inventario, &numVehiculos);

    do {
        mostrarMenu();
        opcion = ingresarEnteroPositivo("Seleccione una opcion");

        switch (opcion) {
            case 1:
                registrarVehiculo(inventario, &numVehiculos);
                break;
            case 2:
                mostrarInventario(inventario, numVehiculos);
                break;
            case 3:
                buscarVehiculos(inventario, numVehiculos);
                break;
            case 4:
                registrarVenta(inventario, numVehiculos);
                break;
            case 5:
                reporteVentasDelDia(inventario, numVehiculos);
                reporteVehiculosVendidos(inventario, numVehiculos);
                break;
            case 6:
                printf("Saliendo del sistema...\n");
                break;
            default:
                printf("Opcion invalida.\n");
        }

    } while (opcion != 6);

    return 0;
}

