#include <stdio.h>
#include <string.h>
#include "vehiculos.h"
#include "validaciones.h"


void mostrarMenu() {
    printf("\n===== CONCESIONARIA RUEDAS DE ORO =====\n");
    printf("1. Registrar vehiculo\n");
    printf("2. Ver inventario\n");
    printf("3. Buscar vehiculo\n");
    printf("4. Registrar venta\n");
    printf("5. Reporte de vehiculos vendidos\n");
    printf("6. Salir\n");
}



void cargarInventario(struct Vehiculo inventario[], int *numVehiculos) {
    FILE *archivo = fopen("inventario.txt", "r");

    if (archivo == NULL) {
        *numVehiculos = 0;
        return;
    }

    *numVehiculos = 0;

    while (*numVehiculos < MAX_VEHICULOS && fscanf(archivo, "%d %s %s %s %d %f %s",
        &inventario[*numVehiculos].id,
        inventario[*numVehiculos].tipo,
        inventario[*numVehiculos].marca,
        inventario[*numVehiculos].modelo,
        &inventario[*numVehiculos].anio,
        &inventario[*numVehiculos].precio,
        inventario[*numVehiculos].estado) == 7) {

        (*numVehiculos)++;
    }

    fclose(archivo);
}


void guardarInventario(struct Vehiculo inventario[], int numVehiculos) {
    FILE *archivo = fopen("inventario.txt", "w");

    for (int i = 0; i < numVehiculos; i++) {
        fprintf(archivo, "%d %s %s %s %d %.2f %s\n",
                inventario[i].id,
                inventario[i].tipo,
                inventario[i].marca,
                inventario[i].modelo,
                inventario[i].anio,
                inventario[i].precio,
                inventario[i].estado);
    }

    fclose(archivo);
}



void registrarVehiculo(struct Vehiculo inventario[], int *numVehiculos) {
    if (*numVehiculos >= MAX_VEHICULOS) {
        printf("Inventario lleno.\n");
        return;
    }
    inventario[*numVehiculos].id = *numVehiculos + 1;

    ingresarCadena("Tipo", inventario[*numVehiculos].tipo, 20);
    ingresarCadena("Marca", inventario[*numVehiculos].marca, 30);
    ingresarCadena("Modelo", inventario[*numVehiculos].modelo, 30);

    inventario[*numVehiculos].anio = ingresarEnteroPositivo("Anio");
    inventario[*numVehiculos].precio = ingresarFlotante("Precio");

    strcpy(inventario[*numVehiculos].estado, "Disponible");

    (*numVehiculos)++;

    guardarInventario(inventario, *numVehiculos);

    printf("Vehiculo registrado correctamente.\n");
}

void mostrarInventario(struct Vehiculo inventario[], int numVehiculos) {
    if (numVehiculos == 0) {
        printf("No hay vehiculos registrados.\n");
        return;
    }
    for (int i = 0; i < numVehiculos; i++) {
        printf("\nID: %d", inventario[i].id);
        printf("\nTipo: %s", inventario[i].tipo);
        printf("\nMarca: %s", inventario[i].marca);
        printf("\nModelo: %s", inventario[i].modelo);
        printf("\nAño: %d", inventario[i].anio);
        printf("\nPrecio: %.2f", inventario[i].precio);
        printf("\nEstado: %s", inventario[i].estado);
        printf("\n-------------------------\n");
    }
}

void buscarVehiculos(struct Vehiculo inventario[], int numVehiculos) {
    char tipoBuscado[20];
    char marcaBuscada[30];
    float presupuesto;

    ingresarCadena("Tipo", tipoBuscado, 20);
    ingresarCadena("Marca", marcaBuscada, 30);
    presupuesto = ingresarFlotante("Presupuesto maximo");

    int encontrados = 0;

    for (int i = 0; i < numVehiculos; i++) {

        if (strcmp(inventario[i].estado, "Disponible") == 0) {

            if(strcmp(inventario[i].tipo, tipoBuscado) == 0){

                if (strcmp(inventario[i].marca, marcaBuscada) == 0) {

                if (inventario[i].precio <= presupuesto) {

                    printf("\nID: %d - %s %s ($%.2f)\n",
                           inventario[i].id,
                           inventario[i].marca,
                           inventario[i].modelo,
                           inventario[i].precio);

                    encontrados++;
                }
            }

            }
            
        }
    }

    if (encontrados == 0) {
        printf("No se encontraron vehiculos.\n");
    }
}

void registrarVenta(struct Vehiculo inventario[], int numVehiculos) {
    int id;
    char cliente[40];

    id = ingresarEnteroPositivo("Ingrese ID del vehiculo");
    while (getchar() != '\n');
    
    ingresarCadena("Nombre del cliente", cliente, 40);

    for (int i = 0; i < numVehiculos; i++) {

        if (inventario[i].id == id) {

            if (strcmp(inventario[i].estado, "Disponible") == 0) {

                strcpy(inventario[i].estado, "Vendido");
                guardarInventario(inventario, numVehiculos);
                printf("Venta registrada correctamente a %s.\n", cliente);
                return;
            }
        }
    }

    printf("Vehiculo no encontrado.\n");
}

void reporteVehiculosVendidos(struct Vehiculo inventario[], int numVehiculos) {
    printf("\n--- VEHICULOS VENDIDOS ---\n");

    int encontrados = 0;
    float totalVentas = 0.0;

    for (int i = 0; i < numVehiculos; i++) {
        if (strcmp(inventario[i].estado, "Vendido") == 0) {
            printf(" %d %s %s (%s) - $%.2f\n",
                   inventario[i].id,
                   inventario[i].marca,
                   inventario[i].modelo,
                   inventario[i].tipo,
                   inventario[i].precio);
                
                   totalVentas += inventario[i].precio;
                encontrados ++;
        }
    }
    if(encontrados == 0){
        printf("No hay vehiculos vendidos.\n");
    }else{
        printf("\nTotal vendido: $%.2f\n", totalVentas);
    }
}




