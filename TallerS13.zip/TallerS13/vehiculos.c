#include <stdio.h>
#include <string.h>
#include "vehiculos.h"
#include "validaciones.h"

void mostrarMenu() {
    printf("\n===== CONCESIONARIA RUEDAS DE ORO =====\n");
    printf("1. Registrar vehiculo\n");
    printf("2. Ver inventario\n");
    printf("3. Buscar vehiculo\n");
    printf("4. Registrar venta\n");
    printf("5. Reportes de ventas\n");
    printf("6. Salir\n");
}

void inicializarVehiculos(struct Vehiculo inventario[], int *numVehiculos) {
    inventario[0].id = 1;
    strcpy(inventario[0].tipo, "Camioneta");
    strcpy(inventario[0].marca, "Toyota");
    strcpy(inventario[0].modelo, "Hilux");
    inventario[0].anio = 2025;
    inventario[0].precio = 35000;
    strcpy(inventario[0].estado, "Disponible");
    inventario[0].vendido = 0;

    inventario[1].id = 2;
    strcpy(inventario[1].tipo, "Auto");
    strcpy(inventario[1].marca, "Hyundai");
    strcpy(inventario[1].modelo, "Accent");
    inventario[1].anio = 2018;
    inventario[1].precio = 12593;
    strcpy(inventario[1].estado, "Disponible");
    inventario[1].vendido = 0;

    inventario[2].id = 3;
    strcpy(inventario[2].tipo, "Camioneta");
    strcpy(inventario[2].marca, "Chevrolet");
    strcpy(inventario[2].modelo, "Tracker");
    inventario[2].anio = 2020;
    inventario[2].precio = 14500;
    strcpy(inventario[2].estado, "Disponible");
    inventario[2].vendido = 0;

    inventario[3].id = 4;
    strcpy(inventario[3].tipo, "Auto");
    strcpy(inventario[3].marca, "Kia");
    strcpy(inventario[3].modelo, "Picanto");
    inventario[3].anio = 2017;
    inventario[3].precio = 9000;
    strcpy(inventario[3].estado, "Vendido");
    inventario[3].vendido = 1;

    *numVehiculos = 4;
}

void registrarVehiculo(struct Vehiculo inventario[], int *numVehiculos) {
    if (*numVehiculos >= MAX_VEHICULOS) {
        printf("Inventario lleno.\n");
        return;
    }

    inventario[*numVehiculos].id = *numVehiculos + 1;

    ingresarCadena("Tipo", inventario[*numVehiculos].tipo, 20);
    ingresarCadena("Marca", inventario[*numVehiculos].marca, 30);
    ingresarCadena("Modelo", inventario[*numVehiculos].modelo, 30);

    printf("Anio: ");
    scanf("%d", &inventario[*numVehiculos].anio);
    while (getchar() != '\n');

    inventario[*numVehiculos].precio = ingresarFlotante("Precio");

    strcpy(inventario[*numVehiculos].estado, "Disponible");
    inventario[*numVehiculos].vendido = 0;

    (*numVehiculos)++;

    printf("Vehiculo registrado correctamente.\n");
}

void mostrarInventario(struct Vehiculo inventario[], int numVehiculos) {
    printf("\nID | TIPO | MARCA | MODELO | ANIO | PRECIO | ESTADO\n");
    for (int i = 0; i < numVehiculos; i++) {
        printf("%d | %s | %s | %s | %d | %.2f | %s\n",
               inventario[i].id,
               inventario[i].tipo,
               inventario[i].marca,
               inventario[i].modelo,
               inventario[i].anio,
               inventario[i].precio,
               inventario[i].estado);
    }
}

void buscarVehiculos(struct Vehiculo inventario[], int numVehiculos) {
    char tipo[20], marca[30];
    float presupuesto;

    ingresarCadena("Tipo", tipo, 20);
    ingresarCadena("Marca", marca, 30);
    presupuesto = ingresarFlotante("Presupuesto maximo");

    int encontrado = 0; // Para mostrar mensaje si no hay coincidencias

    for (int i = 0; i < numVehiculos; i++) {
        if (strcmp(inventario[i].estado, "Disponible") == 0) {
            if (strcmp(inventario[i].tipo, tipo) == 0) {
                if (strcmp(inventario[i].marca, marca) == 0) {
                    if (inventario[i].precio <= presupuesto) {
                        printf("%d - %s %s ($%.2f)\n",
                               inventario[i].id,
                               inventario[i].marca,
                               inventario[i].modelo,
                               inventario[i].precio);
                        encontrado = 1;
                    }
                }
            }
        }
    }

    if (!encontrado) {
        printf("No se encontraron vehiculos que cumplan los criterios.\n");
    }
}

void registrarVenta(struct Vehiculo inventario[], int numVehiculos) {
    int id;
    char cliente[50];

    id = ingresarEnteroPositivo("Ingrese ID del vehiculo");
    ingresarCadena("Nombre del cliente", cliente, 50);

    int vendido = 0;

    for (int i = 0; i < numVehiculos; i++) {
        if (inventario[i].id == id) {
            if (strcmp(inventario[i].estado, "Disponible") == 0) {
                strcpy(inventario[i].estado, "Vendido");
                inventario[i].vendido = 1;
                printf("Venta realizada a %s.\n", cliente);
                vendido = 1;
                break;
            }
        }
    }

    if (!vendido) {
        printf("Vehiculo no disponible.\n");
    }
}

void reporteVentasDelDia(struct Vehiculo inventario[], int numVehiculos) {
    printf("\n--- VENTAS DEL DIA ---\n");

    for (int i = 0; i < numVehiculos; i++) {
        if (inventario[i].vendido == 1) {
            printf("%s %s - $%.2f\n",
                   inventario[i].marca,
                   inventario[i].modelo,
                   inventario[i].precio);
        }
    }
}

void reporteVehiculosVendidos(struct Vehiculo inventario[], int numVehiculos) {
    printf("\n--- VEHICULOS VENDIDOS ---\n");

    for (int i = 0; i < numVehiculos; i++) {
        if (inventario[i].vendido == 1) {
            printf("%s %s (%s)\n",
                   inventario[i].marca,
                   inventario[i].modelo,
                   inventario[i].tipo);
        }
    }
}

