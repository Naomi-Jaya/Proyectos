#include <stdio.h>
#include <string.h>
#include "validaciones.h"

int ingresarEnteroPositivo(char *mensaje) {
    int numero;
    printf("%s: ", mensaje);
    while (scanf("%d", &numero) != 1 || numero <= 0) {
        while (getchar() != '\n');
        printf("Ingrese un entero positivo: ");
    }
    while (getchar() != '\n');
    return numero;
}

float ingresarFlotante(char *mensaje) {
    float numero;
    printf("%s: ", mensaje);
    while (scanf("%f", &numero) != 1 || numero <= 0) {
        while (getchar() != '\n');
        printf("Ingrese un valor valido: ");
    }
    while (getchar() != '\n');
    return numero;
}

void ingresarCadena(char *mensaje, char *cadena, int limite) {
    printf("%s: ", mensaje);
    fgets(cadena, limite, stdin);
    cadena[strcspn(cadena, "\n")] = '\0';
}
