#include <stdio.h>
#include <string.h>
#include "validaciones.h"

int ingresarEnteroPositivo(char *mensaje) {
    int v;
    printf("%s: ", mensaje);
    while (scanf("%d", &v) != 1 || v <= 0) {
        while (getchar() != '\n');
        printf("Ingrese un entero positivo: ");
    }
    while (getchar() != '\n');
    return v;
}

float ingresarFlotante(char *mensaje) {
    float v;
    printf("%s: ", mensaje);
    while (scanf("%f", &v) != 1 || v <= 0) {
        while (getchar() != '\n');
        printf("Ingrese un valor valido: ");
    }
    while (getchar() != '\n');
    return v;
}

void ingresarCadena(char *mensaje, char *cadena, int tam) {
    printf("%s: ", mensaje);
    fgets(cadena, tam, stdin);
    cadena[strcspn(cadena, "\n")] = '\0';
}
