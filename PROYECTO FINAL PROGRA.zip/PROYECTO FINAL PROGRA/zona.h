#define ZONA_H

#define DIAS 30

typedef struct {
    char nombre[40];

    float pm25_hist[DIAS];
    float no2_hist[DIAS];
    float so2_hist[DIAS];
    float co2_hist[DIAS];

    float pm25_actual;
    float no2_actual;
    float so2_actual;
    float co2_actual;

    float temperatura;
    float humedad;
    float viento;

    float prom_pm25;
    float prom_no2;
    float prom_so2;
    float prom_co2;

    float pred_pm25;
    int alerta;
} Zona;

void inicializarZona(Zona *z, const char *nombre);
