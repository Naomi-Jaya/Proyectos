void ingresarProductos(char nombres[][30], float precios[], int numeroProductos);
void mostrarProductos(char nombres[][30], float precios[], int numeroProductos);

float calcularTotal(float precios[], int numeroProductos);
int indiceMax(float precios[], int numeroProductos);
int indiceMin(float precios[], int numeroProductos);
float precioPromedio(float precios[], int numeroProductos);

int buscarProducto(char nombres[][30], float precios[], int numeroProductos, char productoBuscado[]);
