#include <stdio.h>
#include <string.h>
#include "inventario.h"
#include "validaciones.h"


void ingresarProductos(char nombres[][30], float precios[], int numeroProductos) {
    for (int i = 0; i < numeroProductos; i++) {
        printf("\nIngrese nombre del producto %d: \n", i + 1);
        scanf("%s", nombres[i]);  // sin espacios

        precios[i] = ingresarFlotantePositivo("Precio");
    }
}


void mostrarProductos(char nombres[][30], float precios[], int numeroProductos) {
    printf("\n--- LISTA DE PRODUCTOS ---\n");
    for (int i = 0; i < numeroProductos; i++) {
        printf("%d. %s - $%.2f\n", i + 1, nombres[i], precios[i]);
    }
}


float calcularTotal(float precios[], int numeroProductos) {
    float total = 0;
    for (int i = 0; i < numeroProductos; i++)
        total += precios[i];
    return total;
}

int indiceMax(float precios[], int numeroProductos) {
    int indice = 0;
    for (int i = 1; i < numeroProductos; i++) {
        if (precios[i] > precios[indice]) {
            indice = i;
        }
    }
    return indice;
}

int indiceMin(float precios[], int numeroProductos) {
    int indice = 0;
    for (int i = 1; i < numeroProductos; i++) {
        if (precios[i] < precios[indice]) {
            indice = i;
        }
    }
    return indice;
}

float precioPromedio(float precios[], int numeroProductos) {
    return calcularTotal(precios, numeroProductos) / numeroProductos;
}


int buscarProducto(char nombres[][30], float precios[], int numeroProductos, char productoBuscado[]) {
    for (int i = 0; i < numeroProductos; i++) {
        if (strcmp(nombres[i], productoBuscado) == 0)
            return i; // encontrado
    }
    return -1; // no encontrado
}
