float ingresarFlotantePositivo(char *mensaje);
float ingresarFlotanteMayorIgual(char *mensaje, float minimo);
float ingresarFlotanteMenorIgual(char *mensaje, float maximo);
float ingresarFlotanteEnRango(char *mensaje, float minimo, float maximo);

int ingresarEnteroPositivo(char *mensaje);
int ingresarEnteroEnRango(char *mensaje, int minimo, int maximo);
