#include <stdio.h>
#include <string.h>
#include "inventario.h"
#include "validaciones.h"

int main() {
    char nombres[10][30];
    float precios[10];
    int numeroProductos = 0;
    int opcion;

    printf("¿Cuántos productos desea ingresar? (1 - 10)\n");
    numeroProductos = ingresarEnteroEnRango("Ingrese cantidad", 1, 10);

    ingresarProductos(nombres, precios, numeroProductos);

    do {
        printf("\n===== MENU DE INVENTARIO =====\n");
        printf("1. Mostrar precio total\n");
        printf("2. Mostrar producto más caro\n");
        printf("3. Mostrar producto más barato\n");
        printf("4. Mostrar precio promedio\n");
        printf("5. Buscar producto por nombre\n");
        printf("6. Salir\n");

        opcion = ingresarEnteroEnRango("Seleccione una opción", 1, 6);

        switch (opcion) {
            case 1:
                printf("Precio total: %.2f\n", calcularTotal(precios, numeroProductos));
                break;

            case 2:
                int maximo = indiceMax(precios, numeroProductos);
                printf("Producto más caro: %s - cuesta %.2f\n", nombres[maximo], precios[maximo]);
                break;

            case 3:
                int minimo = indiceMin(precios, numeroProductos);
                printf("Producto más barato: %s - cuesta %.2f\n", nombres[minimo], precios[minimo]);
                break;

            case 4:
                printf("Precio promedio: %.2f\n", precioPromedio(precios, numeroProductos));
                break;

            case 5: {
                char buscarNombre[30];
                printf("Ingrese el nombre del producto a buscar: ");
                scanf("%s", buscarNombre);

                int indiceProducto = buscarProducto(nombres, precios, numeroProductos, buscarNombre);

                if (indiceProducto == -1)
                    printf("Producto NO encontrado.\n");
                else
                    printf("Producto encontrado: %s cuesta %.2f\n",
                           nombres[indiceProducto],
                           precios[indiceProducto]);
                break;
            }

            case 6:
                printf("Saliendo...\n");
                break;
        }

    } while (opcion != 6);

    return 0;
}

