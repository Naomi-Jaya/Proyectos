#include <stdio.h>

#define MAX_LIBROS 10

struct Libro {
    int id;
    char titulo[100];
    char autor[50];
    int anio_publicacion;
    char estado[12]; // "Disponible" o "Prestado"
};

void mostrarMenu();
void registrarLibro(struct Libro biblioteca[], int *numLibros);
void mostrarInventario(struct Libro biblioteca[], int numLibros);
void buscarLibro(struct Libro biblioteca[], int numLibros);
void actualizarEstado(struct Libro biblioteca[], int numLibros);
void eliminarLibro(struct Libro biblioteca[], int *numLibros);
int libroValido(int id, struct Libro biblioteca[], int numLibros);
void inicializarBaseDeDatos(struct Libro biblioteca[], int *numLibros);
