#include <stdio.h>
#include <string.h>
#include "biblioteca.h"
#include "validaciones.h"

void registrarLibro(struct Libro biblioteca[], int *numLibros) {

    if (*numLibros >= MAX_LIBROS) {
        printf("No se pueden registrar mas libros.\n");
        return;
    }

    int id = ingresarEnteroPositivo("Ingrese el ID del libro");
    while (getchar() != '\n');
    if (libroValido(id, biblioteca, *numLibros)) {
        printf("Ese ID ya existe.\n");
        return;
    }

    biblioteca[*numLibros].id = id;

    ingresarCadena("Ingrese el titulo", biblioteca[*numLibros].titulo, 100);
    ingresarCadena("Ingrese el autor", biblioteca[*numLibros].autor, 50);
    biblioteca[*numLibros].anio_publicacion =
        ingresarEnteroEnRango("Ingrese el anio de publicacion", 1000, 2025);

    strcpy(biblioteca[*numLibros].estado, "Disponible");

    (*numLibros)++;
    printf("Libro registrado correctamente.\n");
}

void mostrarMenu() {
    printf("\n===== MENU BIBLIOTECA =====\n");
    printf("1. Registrar libro\n");
    printf("2. Ver inventario\n");
    printf("3. Buscar libro\n");
    printf("4. Cambiar estado\n");
    printf("5. Eliminar libro\n");
    printf("6. Salir\n");
}

void mostrarInventario(struct Libro biblioteca[], int numLibros) {

    printf("\n==============================================\n");
    printf("| ID | TITULO | AUTOR | ANIO | ESTADO |\n");
    printf("==============================================\n");

    for (int i = 0; i < numLibros; i++) {
        printf("| %d | %s | %s | %d | %s |\n",
               biblioteca[i].id,
               biblioteca[i].titulo,
               biblioteca[i].autor,
               biblioteca[i].anio_publicacion,
               biblioteca[i].estado);
    }

    printf("==============================================\n");
}

void buscarLibro(struct Libro biblioteca[], int numLibros) {
    int opcion;
    int id;
    char titulo[100];

    printf("\nBuscar libro por:\n");
    printf("1. ID\n");
    printf("2. Titulo\n");
    opcion = ingresarEnteroEnRango("Seleccione una opcion", 1, 2);

    if (opcion == 1) {
        id = ingresarEnteroPositivo("Ingrese el ID del libro");

        for (int i = 0; i < numLibros; i++) {
            if (biblioteca[i].id == id) {
                printf("\nLibro encontrado:\n");
                printf("ID: %d\n", biblioteca[i].id);
                printf("Titulo: %s\n", biblioteca[i].titulo);
                printf("Autor: %s\n", biblioteca[i].autor);
                printf("Anio: %d\n", biblioteca[i].anio_publicacion);
                printf("Estado: %s\n", biblioteca[i].estado);
                return;
            }
        }
    } 
    else {
        while(getchar() != '\n');

        ingresarCadena("Ingrese el titulo del libro: ", titulo,100);

        for (int i = 0; i < numLibros; i++) {
            if (strcmp(biblioteca[i].titulo, titulo) == 0) {
                printf("\nLibro encontrado:\n");
                printf("ID: %d\n", biblioteca[i].id);
                printf("Titulo: %s\n", biblioteca[i].titulo);
                printf("Autor: %s\n", biblioteca[i].autor);
                printf("Anio: %d\n", biblioteca[i].anio_publicacion);
                printf("Estado: %s\n", biblioteca[i].estado);
                return;
            }
        }
    }

    printf("Libro no encontrado.\n");
}


void actualizarEstado(struct Libro biblioteca[], int numLibros) {
    int id = ingresarEnteroPositivo("Ingrese el ID del libro");

    for (int i = 0; i < numLibros; i++) {
        if (biblioteca[i].id == id) {
            // Guardamos el estado actual
            char estadoAnterior[12];
            strcpy(estadoAnterior, biblioteca[i].estado);

            // Cambiamos el estado
            if (strcmp(biblioteca[i].estado, "Disponible") == 0) {
                strcpy(biblioteca[i].estado, "Prestado");
            } else {
                strcpy(biblioteca[i].estado, "Disponible");
            }

            printf("El estado del libro '%s' ha cambiado de '%s' a '%s'.\n",
                   biblioteca[i].titulo,
                   estadoAnterior,
                   biblioteca[i].estado);
            return;
        }
    }

    printf("Libro no encontrado.\n");
}




void eliminarLibro(struct Libro biblioteca[], int *numLibros) {
    int id = ingresarEnteroPositivo("Ingrese el ID del libro a eliminar");

    for (int i = 0; i < *numLibros; i++) {
        if (biblioteca[i].id == id) {
            for (int j = i; j < *numLibros - 1; j++) {
                biblioteca[j] = biblioteca[j + 1];
            }
            (*numLibros)--;
            printf("Libro eliminado correctamente.\n");
            return;
        }
    }
    printf("Libro no encontrado.\n");
}

int libroValido(int id, struct Libro biblioteca[], int numLibros) {
    for (int i = 0; i < numLibros; i++) {
        if (biblioteca[i].id == id)
            return 1;
    }
    return 0;
}

void inicializarBaseDeDatos(struct Libro biblioteca[], int *numLibros) {

    biblioteca[0].id = 1;
    strcpy(biblioteca[0].titulo, "Cien años de soledad");
    strcpy(biblioteca[0].autor, "Gabriel Garcia Marquez");
    biblioteca[0].anio_publicacion = 1967;
    strcpy(biblioteca[0].estado, "Disponible");

    biblioteca[1].id = 2;
    strcpy(biblioteca[1].titulo, "1984");
    strcpy(biblioteca[1].autor, "George Orwell");
    biblioteca[1].anio_publicacion = 1949;
    strcpy(biblioteca[1].estado, "Prestado"); 

    biblioteca[2].id = 3;
    strcpy(biblioteca[2].titulo, "El principito");
    strcpy(biblioteca[2].autor, "Antoine de Saint-Exupery");
    biblioteca[2].anio_publicacion = 1943;
    strcpy(biblioteca[2].estado, "Disponible");

    biblioteca[3].id = 4;
    strcpy(biblioteca[3].titulo, "La sombra del viento");
    strcpy(biblioteca[3].autor, "Carlos Ruiz Zafon");
    biblioteca[3].anio_publicacion = 2001;
    strcpy(biblioteca[3].estado, "Disponible");

    *numLibros = 4;
}


