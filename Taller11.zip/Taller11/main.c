#include <stdio.h>
#include "biblioteca.h"
#include "validaciones.h"

int main() {
    struct Libro biblioteca[MAX_LIBROS];
    int numLibros = 0;
    int opcion;

    inicializarBaseDeDatos(biblioteca, &numLibros);

    do {
        mostrarMenu();
        opcion = ingresarEnteroEnRango("Seleccione una opcion", 1, 6);

        switch (opcion) {
            case 1:
                registrarLibro(biblioteca, &numLibros);
                break;
            case 2:
                mostrarInventario(biblioteca, numLibros);
                break;
            case 3:
                buscarLibro(biblioteca, numLibros);
                break;
            case 4:
                actualizarEstado(biblioteca, numLibros);
                break;
            case 5:
                eliminarLibro(biblioteca, &numLibros);
                break;
            case 6:
            printf("Saliendo del sistema...\n");
            break;

        }

    } while (opcion != 6);

    return 0;
}
