int ingresarEnteroPositivo(char *mensaje);
int ingresarEnteroEnRango(char *mensaje, int minimo, int maximo);
void ingresarCadena(char *mensaje, char *cadena, int tamano);
