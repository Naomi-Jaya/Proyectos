int validarEnteroPositivo(char mensaje[]);
float validarFlotantePositivo(char mensaje[]);
void validarCadena(char *cadena, char mensaje[]);