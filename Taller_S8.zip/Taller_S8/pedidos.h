#include "productos.h"

#define MAX_PEDIDO 25

// Coinciden con las definiciones de pedidos.c y con el main
float calcularTiempoTotal(char pedido[][NOMBRE_PRODUCTO],
                          int cantidades[],
                          float tiempos[],
                          char productos[][NOMBRE_PRODUCTO],
                          int totalPedidos);

float calcularRecursosTotales(char pedido[][NOMBRE_PRODUCTO],
                              int cantidades[],
                              float recursos[],
                              char productos[][NOMBRE_PRODUCTO],
                              int totalPedidos);

int verificarRecursosPasoAPaso(char pedido[][NOMBRE_PRODUCTO],
                               int cantidades[],
                               float recursos[],
                               float recursosDisponibles,
                               char productos[][NOMBRE_PRODUCTO],
                               int totalPedidos);
// Busca un producto en el pedido y devuelve su índice, -1 si no existe
int buscarProductoEnPedido(char pedido[][NOMBRE_PRODUCTO], int totalPedidos, char nombre[]);

// Edita un pedido existente
void editarPedido(char pedido[][NOMBRE_PRODUCTO], int cantidades[], int totalPedidos);

// Elimina un pedido existente
int eliminarPedido(char pedido[][NOMBRE_PRODUCTO], int cantidades[], int totalPedidos);
