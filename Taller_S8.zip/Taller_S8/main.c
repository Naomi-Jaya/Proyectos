#include <stdio.h>
#include "productos.h"
#include "pedidos.h"
#include "validaciones.h"

int main() {

    char productos[MAX_FAB][NOMBRE_PRODUCTO];
    float tiempos[MAX_FAB];
    float recursos[MAX_FAB];

    cargarProductos(productos, tiempos, recursos);


    char pedidoNombres[MAX_PEDIDO][NOMBRE_PRODUCTO];
    int cantidades[MAX_PEDIDO];
    int totalPedidos = 0;

    float tiempoDisponibleHoras = 275.0;
    float recursosDisponibles = 200.0;


    printf("===================================================\n");
    printf("   BIENVENIDO A MI FABRICA DE COMPONENTES ELECTRONICOS\n");
    printf("===================================================\n\n");

    printf("Estos son los 5 productos que elaboramos:\n\n");
    printf("1. sensor       | Tiempo: 8 h | Recursos: 6\n");
    printf("2. microchip    | Tiempo: 25 h | Recursos: 12\n");
    printf("3. resistor     | Tiempo: 3 h | Recursos: 1\n");
    printf("4. condensador  | Tiempo: 6 h | Recursos: 2\n");
    printf("5. LED          | Tiempo: 2 h | Recursos: 1\n\n");

    int opcion;

    do {
        printf("\n--- MENU ---\n");
        printf("1. Agregar producto al pedido\n");
        printf("2. Mostrar tiempo total del pedido\n");
        printf("3. Mostrar recursos totales del pedido\n");
        printf("4. Verificar si se puede cumplir el pedido\n");
        printf("5. Editar un producto del pedido\n");
        printf("6. Eliminar un producto del pedido\n");
        printf("7. salir\n");


        opcion = ingresarEnteroEnRango("Ingrese opcion", 1,7 );

                switch(opcion) {
            case 1:
                if (totalPedidos == MAX_PEDIDO) {
                    printf("No se pueden agregar más productos.\n");
                } else {
                    char nombreTemp[NOMBRE_PRODUCTO];
                    int i = 0;
                    printf("Ingrese nombre EXACTO del producto: ");
                    scanf("%s", nombreTemp);

                    while (nombreTemp[i] != '\0') {
                        pedidoNombres[totalPedidos][i] = nombreTemp[i];
                        i++;
                    }
                    pedidoNombres[totalPedidos][i] = '\0';

                    cantidades[totalPedidos] = ingresarEnteroPositivo("Cantidad");
                    totalPedidos++;
                    printf("Producto agregado.\n");
                }
                break;

            case 2:
                if (totalPedidos == 0) printf("No hay productos.\n");
                else {
                    float t = calcularTiempoTotal(pedidoNombres, cantidades,
                                                  tiempos, productos, totalPedidos);
                    printf("Tiempo total del pedido: %.2f horas\n", t);
                }
                break;

            case 3:
                if (totalPedidos == 0) printf("No hay productos.\n");
                else {
                    float r = calcularRecursosTotales(pedidoNombres, cantidades,
                                                      recursos, productos, totalPedidos);
                    printf("Recursos totales requeridos: %.2f unidades\n", r);
                }
                break;

            case 4:
                if (totalPedidos == 0) printf("No hay productos.\n");
                else {
                    float t = calcularTiempoTotal(pedidoNombres, cantidades,
                                                  tiempos, productos, totalPedidos);
                    float r = calcularRecursosTotales(pedidoNombres, cantidades,
                                                      recursos, productos, totalPedidos);

                    printf("Tiempo total: %.2f horas\n", t);
                    printf("Recursos totales: %.2f unidades\n", r);

                    if (t > tiempoDisponibleHoras) {
                        printf("NO hay tiempo suficiente (disp: %.2f horas)\n", tiempoDisponibleHoras);
                    } else {
                        int ok = verificarRecursosPasoAPaso(pedidoNombres, cantidades,
                                                            recursos, recursosDisponibles,
                                                            productos, totalPedidos);
                        if (ok == 1)
                            printf("La fábrica SI puede cumplir el pedido.\n");
                        else
                            printf("La fábrica NO puede cumplir por falta de recursos.\n");
                    }
                }
                break;

            case 5:
                editarPedido(pedidoNombres, cantidades, totalPedidos);
                break;

            case 6:
                totalPedidos = eliminarPedido(pedidoNombres, cantidades, totalPedidos);
                break;

            case 7:
                printf("Saliendo del sistema...\n");
                break;
        }

    } while (opcion != 7);

    return 0;
}



