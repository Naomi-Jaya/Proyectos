#include "productos.h"

/* Carga fija de 5 componentes electrónicos */

void cargarProductos(char productos[][NOMBRE_PRODUCTO], float tiempos[], float recursos[]) {

    char p0[] = "sensor";
    char p1[] = "microchip";
    char p2[] = "resistor";
    char p3[] = "condensador";
    char p4[] = "LED";

    char *fuente[5] = {p0, p1, p2, p3, p4};

    int fila, columna;

    for (fila = 0; fila < MAX_FAB; fila++) {
        columna = 0;
        while (fuente[fila][columna] != '\0') {
            productos[fila][columna] = fuente[fila][columna];
            columna++;
        }
        productos[fila][columna] = '\0';
    }

    // Tiempos reales (minutos)
    tiempos[0] = 8.0;
    tiempos[1] = 25.0;
    tiempos[2] = 3.0;
    tiempos[3] = 6.0;
    tiempos[4] = 2.0;

    // Recursos reales
    recursos[0] = 6.0;
    recursos[1] = 12.0;
    recursos[2] = 1.0;
    recursos[3] = 2.0;
    recursos[4] = 1.0;
}

int compararNombres(char palabra1[], char palabra2[]) {
    int i = 0;
    while (palabra1[i] != '\0' || palabra2[i] != '\0') {
        if (palabra1[i] != palabra2[i]) {
            return 0;
        }
        i++;
    }
    return 1;
}


