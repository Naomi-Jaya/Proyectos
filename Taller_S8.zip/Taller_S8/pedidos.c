#include "pedidos.h"
#include "validaciones.h"
#include <stdio.h>

/* -------------------------------------------------------------------
   Busca un producto por nombre en el catálogo (productos[][]).
   Devuelve el índice (0-4) o -1 si NO existe.
------------------------------------------------------------------- */
int buscarProducto(char productos[][NOMBRE_PRODUCTO], char nombre[]) {
    int f, c;

    for (f = 0; f < MAX_FAB; f++) {
        c = 0;
        int iguales = 1;

        while (productos[f][c] != '\0' || nombre[c] != '\0') {
            if (productos[f][c] != nombre[c]) {
                iguales = 0;
                break;
            }
            c = c + 1;
        }

        if (iguales == 1) {
            return f;
        }
    }
    return -1;
}

/* -------------------------------------------------------------------
   Calcula tiempo total del pedido
------------------------------------------------------------------- */
float calcularTiempoTotal(char pedido[][NOMBRE_PRODUCTO], int cantidades[],
                          float tiempos[], char productos[][NOMBRE_PRODUCTO],
                          int totalPedidos) {

    float total = 0;
    int i;

    for (i = 0; i < totalPedidos; i++) {
        int pos = buscarProducto(productos, pedido[i]);
        if (pos != -1) {
            total = total + tiempos[pos] * cantidades[i];
        }
    }

    return total;
}

/* -------------------------------------------------------------------
   Calcula recursos totales del pedido
------------------------------------------------------------------- */
float calcularRecursosTotales(char pedido[][NOMBRE_PRODUCTO], int cantidades[],
                              float recursos[], char productos[][NOMBRE_PRODUCTO],
                              int totalPedidos) {

    float total = 0;
    int i;

    for (i = 0; i < totalPedidos; i++) {
        int pos = buscarProducto(productos, pedido[i]);
        if (pos != -1) {
            total = total + recursos[pos] * cantidades[i];
        }
    }

    return total;
}

/* -------------------------------------------------------------------
   Verificación paso a paso de recursos
------------------------------------------------------------------- */
int verificarRecursosPasoAPaso(char pedido[][NOMBRE_PRODUCTO], int cantidades[],
                               float recursos[], float recursosDisp,
                               char productos[][NOMBRE_PRODUCTO],
                               int totalPedidos) {

    int i;

    for (i = 0; i < totalPedidos; i++) {
        int pos = buscarProducto(productos, pedido[i]);
        if (pos != -1) {

            float necesita = recursos[pos] * cantidades[i];

            if (recursosDisp < necesita) {
                return 0; // no alcanza
            } else {
                recursosDisp = recursosDisp - necesita;
            }
        }
    }

    return 1; // sí alcanza
}
int buscarProductoEnPedido(char pedido[][NOMBRE_PRODUCTO], int totalPedidos, char nombre[]) {
    int i, j;
    for (i = 0; i < totalPedidos; i++) {
        int iguales = 1;
        for (j = 0; j < NOMBRE_PRODUCTO; j++) {
            if (pedido[i][j] != nombre[j]) {
                iguales = 0;
                break;
            }
            if (nombre[j] == '\0') break;
        }
        if (iguales) return i;
    }
    return -1;
}

void editarPedido(char pedido[][NOMBRE_PRODUCTO], int cantidades[], int totalPedidos) {
    if (totalPedidos == 0) { printf("No hay productos en el pedido.\n"); return; }

    char nombreTemp[NOMBRE_PRODUCTO];
    printf("Ingrese el nombre EXACTO del producto a editar: ");
    scanf("%s", nombreTemp);

    int pos = buscarProductoEnPedido(pedido, totalPedidos, nombreTemp);
    if (pos == -1) { printf("Producto no encontrado.\n"); return; }

    printf("Producto encontrado: %s, Cantidad: %d\n", pedido[pos], cantidades[pos]);

    char nuevoNombre[NOMBRE_PRODUCTO];
    printf("Ingrese nuevo nombre (o mismo nombre para no cambiar): ");
    scanf("%s", nuevoNombre);
    int i = 0; while (nuevoNombre[i] != '\0') { pedido[pos][i] = nuevoNombre[i]; i++; }
    pedido[pos][i] = '\0';

    cantidades[pos] = ingresarEnteroPositivo("Ingrese nueva cantidad");
    printf("Producto actualizado correctamente.\n");
}

int eliminarPedido(char pedido[][NOMBRE_PRODUCTO], int cantidades[], int totalPedidos) {
    if (totalPedidos == 0) { printf("No hay productos en el pedido.\n"); return totalPedidos; }

    char nombreTemp[NOMBRE_PRODUCTO];
    printf("Ingrese el nombre EXACTO del producto a eliminar: ");
    scanf("%s", nombreTemp);

    int pos = buscarProductoEnPedido(pedido, totalPedidos, nombreTemp);
    if (pos == -1) { printf("Producto no encontrado.\n"); return totalPedidos; }

    for (int i = pos; i < totalPedidos - 1; i++) {
        int j = 0;
        while (pedido[i + 1][j] != '\0') { pedido[i][j] = pedido[i + 1][j]; j++; }
        pedido[i][j] = '\0';
        cantidades[i] = cantidades[i + 1];
    }

    totalPedidos--;
    printf("Producto eliminado correctamente.\n");
    return totalPedidos;
}


