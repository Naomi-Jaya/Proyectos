int ingresarEnteroPositivo(char *mensaje);
int ingresarEnteroEnRango(char *mensaje, int minimo, int maximo);
float ingresarFlotantePositivo(char *mensaje);
float ingresarFlotanteEnRango(char *mensaje, float minimo, float maximo);

