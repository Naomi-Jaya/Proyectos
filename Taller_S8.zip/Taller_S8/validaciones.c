#include <stdio.h>
#include "validaciones.h"

int ingresarEnteroPositivo(char *mensaje) {
    int valor;
    printf("%s: ", mensaje);
    while (scanf("%d", &valor) != 1 || valor <= 0) {
        while (getchar() != '\n');
        printf("Debe ser un entero positivo.\n");
        printf("%s: ", mensaje);
    }
    return valor;
}

int ingresarEnteroEnRango(char *mensaje, int minimo, int maximo) {
    int valor;
    printf("%s (%d - %d): ", mensaje, minimo, maximo);
    while (scanf("%d", &valor) != 1 || valor < minimo || valor > maximo) {
        while (getchar() != '\n');
        printf("Debe estar entre %d y %d.\n", minimo, maximo);
        printf("%s (%d - %d): ", mensaje, minimo, maximo);
    }
    return valor;
}

float ingresarFlotantePositivo(char *mensaje) {
    float valor;
    printf("%s: ", mensaje);
    while (scanf("%f", &valor) != 1 || valor <= 0) {
        while (getchar() != '\n');
        printf("El dato debe ser un número positivo.\n");
        printf("%s: ", mensaje);
    }
    return valor;
}

float ingresarFlotanteEnRango(char *mensaje, float minimo, float maximo) {
    float valor;
    printf("%s (%.2f - %.2f): ", mensaje, minimo, maximo);
    while (scanf("%f", &valor) != 1 || valor < minimo || valor > maximo) {
        while (getchar() != '\n');
        printf("Debe estar entre %.2f y %.2f.\n", minimo, maximo);
        printf("%s (%.2f - %.2f): ", mensaje, minimo, maximo);
    }
    return valor;
}
