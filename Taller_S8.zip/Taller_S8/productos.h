#define MAX_FAB 5
#define NOMBRE_PRODUCTO 30

void cargarProductos(char productos[][NOMBRE_PRODUCTO], float tiempos[], float recursos[]);
int compararNombres(char palabra1[], char palabra2[]);

